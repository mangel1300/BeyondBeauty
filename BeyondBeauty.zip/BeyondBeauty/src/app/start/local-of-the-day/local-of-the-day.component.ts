import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-local-of-the-day',
  templateUrl: './local-of-the-day.component.html',
  styleUrls: ['./local-of-the-day.component.scss']
})
export class LocalOfTheDayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
