import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GServicesComponent } from './general-services/gservices/gservices.component';
import { HelpMeComponent } from './help-us/help-me/help-me.component';
import { ContactComponent } from './contacting/contact/contact.component';
import { OfferOfTheDayComponent } from './offers/offer-of-the-day/offer-of-the-day.component';
import { CustomerComponent } from './user/customer/customer.component';
import { BeginningComponent } from './start/beginning/beginning.component';


const rutas: Routes = [
  {
    path: 'inicio', component: BeginningComponent
  },
  {
    path: 'servicios', component: GServicesComponent
  },
  {
    path: 'ofertas', component: OfferOfTheDayComponent
  },
  {
    path: 'usuario', component: CustomerComponent
  },
  {
    path: 'faq', component: HelpMeComponent
  },
  {
    path: 'contacto', component: ContactComponent
  },
  {
    path: '**', component: BeginningComponent
  },
  {
    path: '', redirectTo: '/inicio', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(rutas),
],
  exports: [RouterModule]
})
export class AppRoutingModule { }
