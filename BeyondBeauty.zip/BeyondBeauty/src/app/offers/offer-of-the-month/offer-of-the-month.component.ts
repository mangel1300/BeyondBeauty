import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-of-the-month',
  templateUrl: './offer-of-the-month.component.html',
  styleUrls: ['./offer-of-the-month.component.scss']
})
export class OfferOfTheMonthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
