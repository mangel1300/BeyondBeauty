import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HeaderModule } from './header/header.module';
import { HelpModule } from './help/help.module';
import { FooterModule } from './footer/footer.module';
import { GeneralServicesModule } from './general-services/general-services.module';
import { FAQModule } from './faq/faq.module';
import { StartModule } from './start/start.module';
import { EspecificServicesModule } from './especific-services/especific-services.module';
import { GlocalsModule } from './glocals/glocals.module';
import { ContactingModule } from './contacting/contacting.module';
import { LoginModule } from './login/login.module';
import { OffersModule } from './offers/offers.module';
import { PaymentModule } from './payment/payment.module';
import { UserModule } from './user/user.module';




@NgModule({
  declarations: [
    AppComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ContactingModule,
    EspecificServicesModule,
    FAQModule,
    FooterModule,
    GeneralServicesModule,
    GlocalsModule,
    HeaderModule,
    HelpModule,
    LoginModule,
    OffersModule,
    PaymentModule,
    StartModule,
    UserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
