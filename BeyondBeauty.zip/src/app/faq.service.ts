import { Injectable } from '@angular/core';
import { Faq } from './classes/faq';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class FaqService {

  // url de server
  private serverUrl = 'http://localhost:8080';
  constructor(
    private http: HttpClient
  ) { }

  findAllQuestions(): Observable<Faq[]> {
    const url = this.serverUrl + '/api/faq';
    return this.http.get<Faq[]>(url);
  }

}
