import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './classes/customer';
import { Company } from './classes/company';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})

export class CreateUserService {
  // url de server
  private serverUrl = 'http://localhost:8080';
  constructor(
    private http: HttpClient
  ) { }

  createCustomer(customer: Customer): Observable<Customer> {
    const url = this.serverUrl + '/api/createCustomer';
    return this.http.post<Customer>(url, customer);
  }

  createCompany(company: Company): Observable<Company> {
    const url = this.serverUrl + '/api/createCompany';
    return this.http.post<Company>(url, company);
  }
}
