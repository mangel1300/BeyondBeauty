import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinformation',
  templateUrl: './cinformation.component.html',
  styleUrls: ['./cinformation.component.scss']
})
export class CinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
