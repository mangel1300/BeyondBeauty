import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GInformationComponent } from './ginformation/ginformation.component';


@NgModule({
  declarations: [GInformationComponent],
  imports: [
    CommonModule
  ],
  exports: [GInformationComponent]
})
export class PaymentModule { }
