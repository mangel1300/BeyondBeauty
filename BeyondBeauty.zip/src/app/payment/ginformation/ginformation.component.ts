import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ginformation',
  templateUrl: './ginformation.component.html',
  styleUrls: ['./ginformation.component.scss']
})
export class GInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
