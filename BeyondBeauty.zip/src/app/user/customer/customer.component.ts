import { Component, OnInit } from '@angular/core';
import { UserService } from '../../users.service';
import { Account } from '../../classes/account';
import { Customer } from '../../classes/customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  account: Account;
  customer: Customer;

  ngOnInit() {
    // this.userService.deleteUserLog();
    this.account = this.userService.getUserLoggedIn();
    console.log(this.account);
    if (this.account == null) {
      this.router.navigateByUrl('/log');
    } else {
      this.getCustomers();
      console.log(this.customer);
    }
  }

  getCustomers() {
    this.userService.findOneCustomer(this.account)
        .subscribe(
          cust => {
            this.customer = cust;
          }
        );
  }
}
