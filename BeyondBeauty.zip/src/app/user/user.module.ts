import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerComponent } from './customer/customer.component';
import { CompanyComponent } from './company/company.component';
import { WorkerComponent } from './worker/worker.component';
import { MatCardModule } from '@angular/material';
import { NewServiceComponent } from './new-service/new-service.component';



@NgModule({
  declarations: [CustomerComponent, CompanyComponent, WorkerComponent, NewServiceComponent],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [CompanyComponent, CustomerComponent, WorkerComponent, NewServiceComponent]
})
export class UserModule { }
