import { Component, OnInit} from '@angular/core';
import { Customer} from '../../classes/customer';
import { UserService} from '../../users.service';
import { Company } from '../../classes/company';
import { Worker } from '../../classes/worker';
import { Account } from '../../classes/account';
import { removeSummaryDuplicates } from '@angular/compiler';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.scss']
})
export class LogInComponent implements OnInit {

  classCustomer: Customer;
  classCompany: Company;
  classWorker: Worker;
  classAcount: Account;

  button: boolean;
  login: any;
  choose: any;
  user: any;
  company: any;
  worker: any;

 mondayC: any;
 tuesdayC: any;
 wednesdayC: any;
 thursdayC: any;
 fridayC: any;
 saturdayC: any;

 mondayW: any;
 tuesdayW: any;
 wednesdayW: any;
 thursdayW: any;
 fridayW: any;
 saturdayW: any;

 mondayCText: any;
 tuesdayCText: any;
 wednesdayCText: any;
 thursdayCText: any;
 fridayCText: any;
 saturdayCText: any;

 mondayWText: any;
 tuesdayWText: any;
 wednesdayWText: any;
 thursdayWText: any;
 fridayWText: any;
 saturdayWText: any;

 m: boolean;
 t: boolean;
 x: boolean;
 th: boolean;
 f: boolean;
 s: boolean;

  constructor(
    private createUser: UserService
  ) { }

  ngOnInit() {
    this.classCustomer = new Customer();
    this.classCompany = new Company();
    this.classWorker = new Worker();
    this.classAcount = new Account();

    this.button = true;
    this.login = document.getElementById('login');
    this.choose = document.getElementById('choose');
    this.user = document.getElementById('user-sign');
    this.company = document.getElementById('company-sign');
    this.worker = document.getElementById('worker-sign');

    this.mondayC = document.getElementById('mondayC');
    this.tuesdayC = document.getElementById('tuesdayC');
    this.wednesdayC = document.getElementById('wednesdayC');
    this.thursdayC = document.getElementById('thursdayC');
    this.fridayC = document.getElementById('fridayC');
    this.saturdayC = document.getElementById('saturdayC');

    this.mondayW = document.getElementById('mondayW');
    this.tuesdayW = document.getElementById('tuesdayW');
    this.wednesdayW = document.getElementById('wednesdayW');
    this.thursdayW = document.getElementById('thursdayW');
    this.fridayW = document.getElementById('fridayW');
    this.saturdayW = document.getElementById('saturdayW');

    this.mondayCText = document.getElementById('mondayCText');
    this.tuesdayCText = document.getElementById('tuesdayCText');
    this.wednesdayCText = document.getElementById('wednesdayCText');
    this.thursdayCText = document.getElementById('thursdayCText');
    this.fridayCText = document.getElementById('fridayCText');
    this.saturdayCText = document.getElementById('saturdayCText');

    this.mondayWText = document.getElementById('mondayWText');
    this.tuesdayWText = document.getElementById('tuesdayWText');
    this.wednesdayWText = document.getElementById('wednesdayWText');
    this.thursdayWText = document.getElementById('thursdayWText');
    this.fridayWText = document.getElementById('fridayWText');
    this.saturdayWText = document.getElementById('saturdayWText');

    this.m = true;
    this.t = true;
    this.x = true;
    this.th = true;
    this.f = true;
    this.s = true;
  }

  openChoose() {
    this.button = false;
    this.login.style.display = 'none';
    this.choose.style.display = 'block';
  }

  closeAll() {
    this.user.style.display = 'none';
    this.company.style.display = 'none';
    this.worker.style.display = 'none';
  }

  openUser() {
    this.closeAll();
    this.user.style.display = 'block';
  }

  openCompany() {
    this.closeAll();
    this.company.style.display = 'block';
  }

  openWorker() {
    this.closeAll();
    this.worker.style.display = 'block';
  }

  mondayController() {
    this.m = !this.m;

    if (!this.m) {
      this.mondayCText.disabled = true;
      this.mondayWText.disabled = true;
      this.mondayCText.value = '';
      this.mondayWText.value = '';
    } else {
      this.mondayCText.disabled = false;
      this.mondayWText.disabled = false;
    }
  }

  tuesdayController() {
    this.t = !this.t;

    if (!this.t) {
      this.tuesdayCText.disabled = true;
      this.tuesdayWText.disabled = true;
      this.tuesdayCText.value = '';
      this.tuesdayWText.value = '';
    } else {
      this.tuesdayCText.disabled = false;
      this.tuesdayWText.disabled = false;
    }
  }

  wednesdayController() {
    this.x = !this.x;

    if (!this.x) {
      this.wednesdayCText.disabled = true;
      this.wednesdayWText.disabled = true;
      this.wednesdayCText.value = '';
      this.wednesdayWText.value = '';
    } else {
      this.wednesdayCText.disabled = false;
      this.wednesdayWText.disabled = false;
    }
  }

  thursdayController() {
    this.th = !this.th;

    if (!this.th) {
      this.thursdayCText.disabled = true;
      this.thursdayWText.disabled = true;
      this.thursdayCText.value = '';
      this.thursdayWText.value = '';
    } else {
      this.thursdayCText.disabled = false;
      this.thursdayWText.disabled = false;
    }
  }

  fridayController() {
    this.f = !this.f;

    if (!this.f) {
      this.fridayCText.disabled = true;
      this.fridayWText.disabled = true;
      this.fridayCText.value = '';
      this.fridayWText.value = '';
    } else {
      this.fridayCText.disabled = false;
      this.fridayWText.disabled = false;
    }
  }

  saturdayController() {
    this.s = !this.s;

    if (!this.s) {
      this.saturdayCText.disabled = true;
      this.saturdayWText.disabled = true;
      this.saturdayCText.value = '';
      this.saturdayWText.value = '';
    } else {
      this.saturdayCText.disabled = false;
      this.saturdayWText.disabled = false;
    }
  }

  createConsumer() {
    this.saveCustomer();
  }

   saveCustomer(): void {
    console.log(this.classCustomer);
    this.createUser.createCustomer(this.classCustomer).subscribe();
  }

  createCompany() {
    this.classCompany.schedule = [this.mondayCText.value, this.tuesdayCText.value, this.wednesdayCText.value,
      this.thursdayCText.value, this.fridayCText.value, this.saturdayCText.value];
    console.log(typeof(this.classCompany));
    const temp = new Account();
    temp.nickname = this.classCompany.email;
    temp.password = this.classCompany.password;
    temp.ddbb = 'company';
    this.sign_in(temp);
    this.saveCompany();
  }

  saveCompany(): void {
    console.log(this.classCompany);
    this.createUser.createCompany(this.classCompany).subscribe();
  }

  createWorker() {
    this.classWorker.quadrant = [this.mondayWText.value, this.tuesdayWText.value, this.wednesdayWText.value, this.thursdayWText.value,
    this.fridayWText.value, this.saturdayWText.value
    ];
    this.saveWorker();
  }
  saveWorker() {
    console.log(this.classWorker);
    this.createUser.createWorker(this.classWorker).subscribe();
  }

  log_in() {
    this.findAccount();
  }

  findAccount(): void {
    this.createUser.findAccount(this.classAcount).subscribe();
  }

  sign_in(account: Account): void {
    this.createUser.createAccount(account);
  }
}
