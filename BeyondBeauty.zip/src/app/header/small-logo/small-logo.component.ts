import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-logo',
  templateUrl: './small-logo.component.html',
  styleUrls: ['./small-logo.component.scss']
})
export class SmallLogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
