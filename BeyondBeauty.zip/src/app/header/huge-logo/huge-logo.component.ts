import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-huge-logo',
  templateUrl: './huge-logo.component.html',
  styleUrls: ['./huge-logo.component.scss']
})
export class HugeLogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
