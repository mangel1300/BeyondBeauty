import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndexComponent } from './index/index.component';
import { CopyrightComponent } from './copyright/copyright.component';
import { AppRoutingModule } from '../app-routing.module';



@NgModule({
  declarations: [IndexComponent, CopyrightComponent],
  imports: [
    CommonModule,
    AppRoutingModule
  ],  exports: [CopyrightComponent, IndexComponent]
})
export class FooterModule { }
