export class Company {
    name: string;
    email: string;
    password: string;
    nif: string;
    iban: string;
    schedule: [{
        monday: [{start: string, end: string}],
        tuesday: [{start: string, end: string}],
        wednesday: [{start: string, end: string}],
        thursday: [{start: string, end: string}],
        friday: [{start: string, end: string}],
        saturday: [{start: string, end: string}]
    }];
    direcction: string;
}
