export class Company {
    name: string;
    email: string;
    password: string;
    nif: string;
    iban: string;
    schedule: [
        string, // lunes
        string, // martes
        string, // miercoles
        string, // jueves
        string, // viernes
        string  // sabado
    ];
    direcction: string;
}
