export class Faq {
    question: string;
    answer: string;
}
