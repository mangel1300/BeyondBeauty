export class Worker {
    firstName: string;
    secondName: string;
    dni: string;
    email: string;
    password: string;
    dateBorn: Date;
    ocupation: string;
    company: string;
    quadrant: [
        string, // lunes
        string, // martes
        string, // miercoles
        string, // jueves
        string, // viernes
        string  // sabado
    ];
}
