export class GService {
    title: string;
    description: string;
}
