export class Account {
    nickname: string;
    password: string;
    ddbb: string;
}
