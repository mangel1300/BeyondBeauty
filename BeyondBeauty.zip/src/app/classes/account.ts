export class Account {
    email: string;
    password: string;
    bbdd: string;
}
