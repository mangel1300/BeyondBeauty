export class Customer {
    nickname: string;
    firstName: string;
    secondName: string;
    password: string;
    email: string;
    date: Date;
    points: number;
}