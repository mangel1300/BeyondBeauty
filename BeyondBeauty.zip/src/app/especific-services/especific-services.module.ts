import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SServicesComponent } from './sservices/sservices.component';
import { MatCardModule } from '@angular/material';



@NgModule({
  declarations: [SServicesComponent],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [SServicesComponent]
})
export class EspecificServicesModule { }
