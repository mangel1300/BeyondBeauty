import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sservices',
  templateUrl: './sservices.component.html',
  styleUrls: ['./sservices.component.scss']
})
export class SServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
