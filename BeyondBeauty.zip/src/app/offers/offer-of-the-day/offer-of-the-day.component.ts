import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-of-the-day',
  templateUrl: './offer-of-the-day.component.html',
  styleUrls: ['./offer-of-the-day.component.scss']
})
export class OfferOfTheDayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
