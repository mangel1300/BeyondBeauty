import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllOffersComponent } from './all-offers/all-offers.component';
import { GoffersComponent } from './goffers/goffers.component';
import {MatCardModule} from '@angular/material';


@NgModule({
  declarations: [ AllOffersComponent, GoffersComponent],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [ AllOffersComponent, GoffersComponent]
})
export class OffersModule { }
