import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllOffersComponent } from './all-offers/all-offers.component';
import { GoffersComponent } from './goffers/goffers.component';



@NgModule({
  declarations: [ AllOffersComponent, GoffersComponent],
  imports: [
    CommonModule
  ],
  exports: [ AllOffersComponent, GoffersComponent]
})
export class OffersModule { }
