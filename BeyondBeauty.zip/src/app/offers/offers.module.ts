import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoffersComponent } from './goffers/goffers.component';
import {MatCardModule} from '@angular/material';


@NgModule({
  declarations: [ GoffersComponent],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [GoffersComponent]
})
export class OffersModule { }
