import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-offers',
  templateUrl: './all-offers.component.html',
  styleUrls: ['./all-offers.component.scss']
})
export class AllOffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
