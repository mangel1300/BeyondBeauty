import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goffers',
  templateUrl: './goffers.component.html',
  styleUrls: ['./goffers.component.scss']
})
export class GoffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
