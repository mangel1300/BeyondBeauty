import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CarrouselComponent } from './carrousel/carrousel.component';
import { PrincipalOptionsComponent } from './principal-options/principal-options.component';
import { LocalOfTheDayComponent } from './local-of-the-day/local-of-the-day.component';
import { BeginningComponent } from './beginning/beginning.component';
import { HeaderModule } from '../header/header.module';
import { FooterModule } from '../footer/footer.module';



@NgModule({
  declarations: [CarrouselComponent, PrincipalOptionsComponent, LocalOfTheDayComponent, BeginningComponent],
  imports: [
    CommonModule, HeaderModule, FooterModule
  ], exports: [CarrouselComponent, LocalOfTheDayComponent, PrincipalOptionsComponent]
})
export class StartModule { }
