import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-principal-options',
  templateUrl: './principal-options.component.html',
  styleUrls: ['./principal-options.component.scss']
})
export class PrincipalOptionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
