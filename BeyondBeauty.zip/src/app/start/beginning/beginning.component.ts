import { Component, OnInit } from '@angular/core';
import { AppModule } from '../../app.module';

@Component({
  selector: 'app-beginning',
  templateUrl: './beginning.component.html',
  styleUrls: ['./beginning.component.sass']
})
export class BeginningComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
