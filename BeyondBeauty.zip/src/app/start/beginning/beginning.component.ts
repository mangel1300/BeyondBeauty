import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-beginning',
  templateUrl: './beginning.component.html',
  styleUrls: ['./beginning.component.sass']
})
export class BeginningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
