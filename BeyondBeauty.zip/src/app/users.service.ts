import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './classes/customer';
import { Company } from './classes/company';
import { Worker } from './classes/worker';
import { Account } from './classes/account';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})

export class UserService {
  private acount: Account;
  private isUserLogged: boolean;

  // url de server
  private serverUrl = 'http://localhost:8080';
  constructor(
    private http: HttpClient
  ) {
    this.isUserLogged = false;
   }

   setUserLoggedIn(user: Account) {
    this.isUserLogged = true;
    this.acount = user;
    localStorage.setItem('currentUser', JSON.stringify(this.acount));
   }

   getUserLoggedIn() {
     return JSON.parse(localStorage.getItem('currentUser'));
   }

   deleteUserLog() {
     return localStorage.removeItem('currentUser');
   }

  createCustomer(customer: Customer): Observable<Customer> {
    const url = this.serverUrl + '/api/createCustomer';
    return this.http.post<Customer>(url, customer);
  }

  createCompany(company: Company): Observable<Company> {
    const url = this.serverUrl + '/api/createCompany';
    return this.http.post<Company>(url, company);
  }

  createWorker(worker: Worker): Observable<Worker> {
    const url = this.serverUrl + '/api/createWorker';
    return this.http.post<Worker>(url, worker);
  }

  createAccount(account: Account): Observable<Account> {
    const url = this.serverUrl + '/api/account';
    return this.http.post<Account>(url, account);
  }

  findAccount(account: Account): Observable<Account> {
    const url = this.serverUrl + '/api/findAccount';
    return this.http.post<Account>(url, account);
  }

  findOneCustomer(account: Account): Observable<Customer> {
    const url = this.serverUrl + '/api/customers';
    return this.http.post<Customer>(url, account);
  }

  findAllCompanies(): Observable<Company[]> {
    const url = this.serverUrl + '/api/companies';
    return this.http.get<Company[]>(url);
  }
}
