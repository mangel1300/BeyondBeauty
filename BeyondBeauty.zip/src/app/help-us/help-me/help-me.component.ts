import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-me',
  templateUrl: './help-me.component.html',
  styleUrls: ['./help-me.component.scss']
})
export class HelpMeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
