import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locals',
  templateUrl: './locals.component.html',
  styleUrls: ['./locals.component.scss']
})
export class LocalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
