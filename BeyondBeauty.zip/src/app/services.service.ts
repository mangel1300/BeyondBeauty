import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GService } from './classes/gservice';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  // url de server
  private serverUrl = 'http://localhost:8080';
  constructor(
    private http: HttpClient
  ) { }

  findAllGservices(): Observable<GService[]> {
    const url = this.serverUrl + '/api/gservices';
    return this.http.get<GService[]>(url);
  }

}
