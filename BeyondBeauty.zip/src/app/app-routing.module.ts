import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GServicesComponent } from './general-services/gservices/gservices.component';
import { HelpMeComponent } from './help-us/help-me/help-me.component';
import { ContactComponent } from './contacting/contact/contact.component';
import { CustomerComponent } from './user/customer/customer.component';
import { BeginningComponent } from './start/beginning/beginning.component';
import { CompanyComponent } from './user/company/company.component';
import { WorkerComponent } from './user/worker/worker.component';
import { QuestionsComponent } from './faq/questions/questions.component';
import { LocalsComponent } from './glocals/locals/locals.component';
import { LogInComponent } from './login/log-in/log-in.component';
import { GoffersComponent } from './offers/goffers/goffers.component';


const rutas: Routes = [
  {
    path: 'start', component: BeginningComponent
  },
  {
    path: 'services', component: GServicesComponent
  },
  {
    path: 'locals', component: LocalsComponent
  },
  {
    path: 'offers', component: GoffersComponent
  },
  {
    path: 'customer', component: CustomerComponent
  },
  {
    path: 'company', component: CompanyComponent
  },
  {
    path: 'worker', component: WorkerComponent
  },
  {
    path: 'faq', component: QuestionsComponent
  },
  {
    path: 'log', component: LogInComponent
  },
  {
    path: 'contact', component: ContactComponent
  },
  {
    path: '**', component: BeginningComponent
  },
  {
    path: '', redirectTo: '/inicio', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(rutas),
],
  exports: [RouterModule]
})
export class AppRoutingModule { }
