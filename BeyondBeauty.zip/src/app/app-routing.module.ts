import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GServicesComponent } from './general-services/gservices/gservices.component';
import { HelpMeComponent } from './help-us/help-me/help-me.component';
import { ContactComponent } from './contacting/contact/contact.component';
import { OfferOfTheDayComponent } from './offers/offer-of-the-day/offer-of-the-day.component';
import { CustomerComponent } from './user/customer/customer.component';
import { BeginningComponent } from './start/beginning/beginning.component';
import { CompanyComponent } from './user/company/company.component';
import { WorkerComponent } from './user/worker/worker.component';


const rutas: Routes = [
  {
    path: 'start', component: BeginningComponent
  },
  {
    path: 'services', component: GServicesComponent
  },
  {
    path: 'offers', component: OfferOfTheDayComponent
  },
  {
    path: 'customer', component: CustomerComponent
  },
  {
    path: 'company', component: CompanyComponent
  },
  {
    path: 'worker', component: WorkerComponent
  },
  {
    path: 'faq', component: HelpMeComponent
  },
  {
    path: 'contact', component: ContactComponent
  },
  {
    path: '**', component: BeginningComponent
  },
  {
    path: '', redirectTo: '/inicio', pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(rutas),
],
  exports: [RouterModule]
})
export class AppRoutingModule { }
