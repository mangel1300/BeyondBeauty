import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slocal',
  templateUrl: './slocal.component.html',
  styleUrls: ['./slocal.component.scss']
})
export class SlocalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
