import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlocalComponent} from './slocal/slocal.component';
import {MatCardModule} from '@angular/material';


@NgModule({
  declarations: [SlocalComponent],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports: [SlocalComponent]
})
export class SlocalsModule { }
