import { Component, OnInit } from '@angular/core';
import { GService } from '../../classes/gservice';
import { ServicesService } from '../../services.service';

@Component({
  selector: 'app-gservices',
  templateUrl: './gservices.component.html',
  styleUrls: ['./gservices.component.scss']
})
export class GServicesComponent implements OnInit {

  services: GService[];

  constructor(private servicesService: ServicesService) { }

  ngOnInit(): void {
    console.log('ready for get');
    this.getServices();
  }

  getServices() {
    console.log('recibing all services...');
    return this.servicesService.findAllGservices()
                .subscribe(
                  services => {
                    console.log('servicios' + services);
                    this.services = services;
                  }
                );
  }
}
