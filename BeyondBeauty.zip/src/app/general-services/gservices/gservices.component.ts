import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gservices',
  templateUrl: './gservices.component.html',
  styleUrls: ['./gservices.component.scss']
})
export class GServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
