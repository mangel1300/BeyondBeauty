import { Component, OnInit } from '@angular/core';
import { Faq } from '../../classes/faq';
import { FaqService } from '../../faq.service';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss']
})
export class QuestionsComponent implements OnInit {

  questions: Faq[];

  constructor(private faqService: FaqService) { }

  ngOnInit() {
    console.log('ready to get');
    this.getQuestions();
  }

  getQuestions() {
    console.log('recibing all questions...');
    return this.faqService.findAllQuestions()
                .subscribe(
                  faq => {
                    this.questions = faq;
                  }
                );
  }

}
