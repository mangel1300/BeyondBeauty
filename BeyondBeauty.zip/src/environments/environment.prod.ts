export const environment = {
  production: true, 
  firebaseConfig : {
    apiKey: "AIzaSyBfPLIAlb9LW21x3POtPBTXkyy9iPn4cFg",
    authDomain: "proyecto-79e50.firebaseapp.com",
    databaseURL: "https://proyecto-79e50.firebaseio.com",
    projectId: "proyecto-79e50",
    storageBucket: "proyecto-79e50.appspot.com",
    messagingSenderId: "530370139378",
    appId: "1:530370139378:web:7e4dc7371f34d744e96c6b",
    measurementId: "G-WHWLD79V9X"
  }
};
