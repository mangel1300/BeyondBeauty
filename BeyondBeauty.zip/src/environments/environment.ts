// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false, 
   firebaseConfig : {
    apiKey: "AIzaSyBfPLIAlb9LW21x3POtPBTXkyy9iPn4cFg",
    authDomain: "proyecto-79e50.firebaseapp.com",
    databaseURL: "https://proyecto-79e50.firebaseio.com",
    projectId: "proyecto-79e50",
    storageBucket: "proyecto-79e50.appspot.com",
    messagingSenderId: "530370139378",
    appId: "1:530370139378:web:7e4dc7371f34d744e96c6b",
    measurementId: "G-WHWLD79V9X"
  }

};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
