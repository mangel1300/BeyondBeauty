import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-of-the-week',
  templateUrl: './offer-of-the-week.component.html',
  styleUrls: ['./offer-of-the-week.component.scss']
})
export class OfferOfTheWeekComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
