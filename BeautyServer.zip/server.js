const express = require('express');
const app = express();

app.use(express.json());

const dbConfig = require('./app/config/mongo.config.js');
const mongoose = require('mongoose');
const routes = require('./app/routes/routes');
mongoose.Promise = global.Promise;

mongoose.connect(dbConfig.url, {useNewUrlParser: true, useUnifiedTopology: true})
.then(() => {
    console.log("conexion establecida");
    // const gservices = require('./app/models/gservices.model');

    // gservices.remove({}, function(err){});
    // postServices();
    //postQuestions();

}).catch(err => {
    console.log("conexion fallida");
    process.exit();
})

const cors = require('cors');
const corsOptions = {
    origin: 'http://localhost:4200',
    optionSuccessStatus: 200
}
app.use(cors(corsOptions))

app.use(routes);

//Crear servidor

let port = 8080;
let server = app.listen(port, () => {
    console.log('Servidor en puerto ' + port);
})

function postServices() {
    const GService = require('./app/models/gservices.model');
    let services = [
        {
            title: "Peluquería",
            description: "Todo tipo de cuidados de cabello, ya sea corte, tinte, peinados, planchado, mascarillas, permanentes, etc."
        },
        {
            title: "Barbería",
            description: "Todos los cuidados de la barba, cortes, recortes, arreglos, etc."
        },
        {
            title: "Uñas",
            description: "Cuidado de uñas, tanto manicura como pedicura, ya sea limpieza o decoración, tanto postizas como naturales."
        },
        {
            title: "Cuidado facial",
            description: "Tratamientos especiales para la cara, depilación de cejas, nariz, limpieza y cuidado facial."
        },
        {
            title: "Estetición",
            description: "Depilación corporal, tanto de cera como laser y tratamientos de piel o masajes."
        },
        {
            title: "Maquillaje",
            description: "Maquillajes para todo tipo de eventos, tintes de cejas y pestañas y pestañas postizas."
        }
    ];

    for(let i = 0; i < services.length; i++){
        const service = new GService(services[i]);
        service.save();
    }
    console.log('DONE');
}

function postQuestions() {
    const Questions = require('./app/models/faq.model');
    let questions = [
        {
            question: "¿Como puedo crearme un usuario?", 
            answer: "En el menu superior de la pagina hay una opción 'Usuario' en ella apareceran tres opciones 'Cliente, empresa y trabajador', según " +
                "el tipo de usuario que desee crear pulse su opcioón y le redigirá a el registro de dicha opción. En el registro si cambia de opinion hay un apartado " + 
                "'¿Que eres' en dicho apartado puede elegir que opción desea. Por ultimo, tambien puede registarse en el boton registrar que aparece en el menu de login."
        },
        {
            question: "¿Como puedo modificar mi perfil?",
            answer: "En el menu superior de la pagina hay una opción 'Usuario' en ella apareceran tres opciones 'Cliente, empresa y trabajador', pulse su "+
                "tipo, al final de sus datos aparecerán tres botones 'Aceptar, cancelar y editar', pulse editar y cuando haya acabado de modificar sus datos pulse aceptar " +
                "para confirmarlo."
        },
        {
            question: "¿Si soy una empresa como puedo añadir o modificar a mis trabajadores?",
            answer: "Debe entrar en su perfil (si no sabe como vea la pregunta 2), alli aparecerán sus trabajadores, en la sección 'Mis trabajadores', alli tendrá un boton 'añadir trabajador', "+
                "además apareceran unos recuadros con las fichas de los trabajadores, con dos opciones 'Modificar y despedir'. Que como sus nombres indican sirven para modificar al trabajador, "+
                "dicho boton te enviara al perfil del trabajador donde puede editar sus datos(vease pregunta 2), al darle a despedir se eliminará el trabajador, pero antes le preguntara si esta seguro " +
                "pulse 'Estoy seguro' para despedir al trabajador."
        },
        {
            question: "¿Si soy una empresa como puedo añadir o modificar a mis servicios?",
            answer: "Debe entrar en su perfil(si no sabe como vea la pregunta 2), alli aparecerán sus servicios, en la sección 'Mis servicios', alli tendrá un boton 'añadir servicio', "+
                "además apareceran unos recuadros con las fichas de los servicio, con dos opciones 'Modificar y eliminar'. Que como sus nombres indican sirven para modificar el servicio, " +
                "dicho boton te enviara la pagina de caracteristicas del servicio donde puede editar sus datos, pulsando editar, al darle a eliminar se borrará el servicio, pero antes le preguntara si esta " +
                "seguro pulse 'Estoy seguro' para borrar el servicio."
        },
        {
            question: "¿Como puedo contactar con los administradores de la web?",
            answer: "En el menu superior podrá ver la opción de 'Contacto' alli hay un formulario que puede rellenar para comunicarse con los administradores, dicho formulario tiene " +
                "apartados de ayuda, problema, sujerencias, quejas u otros, elija la opcion que mas le guste y describala en el apartado reservado a ello."
        },
        {
            question: "¿Como puedo ver las ofertas?",
            answer: "En el menu superior entre en 'Ofertas' alli le apareceran todas las disponibles en este momento."
        },
        {
            question: "¿Como puedo ver todos los locales?",
            answer: "Para ello pulse 'Locales' en el menu superior."
        },        
        {
            question: "¿Como puedo ver todos los servicios disponibles?",
            answer: "Para ello pulse 'Servicios' en el menu superior."
        },        
        {
            question: "¿Como puedo saber si un servicio esta en oferta?",
            answer: "Los servicios en oferta aparecen en un color resaltado al resto de los servicios que son mas neutros."
        },
    ];

    for(let i = 0; i < questions.length; i++){
        const question = new Questions(questions[i]);
        question.save();
    }
    console.log('DONE');
}