const express = require('express');
const app = express();

app.use(express.json());

const dbConfig = require('./app/config/mongo.config.js');
const mongoose = require('mongoose');
const routes = require('./app/routes/routes');
mongoose.Promise = global.Promise;

mongoose.connect(dbConfig.url, {useNewUrlParser: true, useUnifiedTopology: true})
.then(() => {
    console.log("conexion establecida");
}).catch(err => {
    console.log("conexion fallida");
    process.exit();
})

const cors = require('cors');
const corsOptions = {
    origin: 'http://localhost:4200',
    optionSuccessStatus: 200
}
app.use(cors(corsOptions))



app.use(routes);

//Crear servidor

let port = 8080;
let server = app.listen(port, () => {


    console.log('Servidor en puerto ' + port);
})