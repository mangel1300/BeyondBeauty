const express = require('express');
const app = express();

app.use(express.json());

const dbConfig = require('./app/config/mongo.config.js');
const mongoose = require('mongoose');
const routes = require('./app/routes/routes');
mongoose.Promise = global.Promise;

mongoose.connect(dbConfig.url, {useNewUrlParser: true, useUnifiedTopology: true})
.then(() => {
    console.log("conexion establecida");

    // postServices();

}).catch(err => {
    console.log("conexion fallida");
    process.exit();
})

const cors = require('cors');
const corsOptions = {
    origin: 'http://localhost:4200',
    optionSuccessStatus: 200
}
app.use(cors(corsOptions))

app.use(routes);

//Crear servidor

let port = 8080;
let server = app.listen(port, () => {
    console.log('Servidor en puerto ' + port);
})

function postServices() {
    const GService = require('./app/models/gservices.model');
    let services = [
        {
            title: "Peluquería",
            description: "Todo tipo de cuidados de cabello, ya sea corte, tinte, saneado, planchado, etc."
        },
        {
            title: "Barbería",
            description: "Todos los cuidados de la barba, cortes, recortes, arreglos, etc."
        },
        {
            title: "Uñas",
            description: "Cuidados de uñas, ya sea manicura o pedicura, ya sea el procedimiento completo o especifico."
        },
        {
            title: "Estetición",
            description: "Cuidado del cuerpo y rostro"
        },
        {
            title: "Maquillaje",
            description: "Cuidados cosmeticos y de belleza"
        }
    ];

    for(let i = 0; i < services.length; i++){
        const service = new GService(services[i]);
        service.save();
    }
    console.log('DONE');
}