const express = require('express');
const router = express.Router();

    const bbdd = require('../controller/bbdd.controller.js');

    //create new user
    router.post('/api/loginCreate', bbdd.createUser);

    //show user
    router.get('/api/user/:userId', bbdd.findOneUser);

    //update user
    router.put('/api/user/:userId', bbdd.updateUser);

    //delete user
    router.delete('/api/user/:userId', bbdd.deleteUser);

    //----------------------------------------------------

    //create new company
    router.post('/api/company', bbdd.createCompany);

    //show company
    router.get('/api/locals/:services', bbdd.findOneCompany);

    //update company
    router.put('/api/user/company/:companyId', bbdd.updateCompany);

    //delete company
    router.delete('/api/company/:companyId', bbdd.deleteCompany);

    //------------------------------------------------------------

    //create worker
    router.post('/api/worker/:workerId', bbdd.createWorker);

    //show worker
    router.get('/api/worker/:workerId', bbdd.findOneWorker);

    //update worker
    router.put('/api/worker/:workerId', bbdd.updateWorker);

    //delete worker
    router.delete('/api/worker/:workerId', bbdd.deleteWorker);


module.exports = router;
