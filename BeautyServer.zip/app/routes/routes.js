module.exports = function(app){

    const bbdd = require('../controller/bbdd.controller.js');

    //create new user
    app.post('/api/loginCreate', bbdd.createUser);

    //show user
    app.get('/api/user/:userId', bbdd.findOneUser);

    //update user
    app.put('/api/user/:userId', bbdd.updateUser);

    //delete user
    app.delete('/api/user/:userId', bbdd.deleteUser);

    //----------------------------------------------------

    //create new company
    app.post('/api/company', bbdd.createCompany);

    //show company
    app.get('/api/locals/:services', bbdd.findCompany);

    //update company
    app.put('/api/user/company/:companyId', bbdd.updateCompany);

    //delete company
    app.delete('/api/company/:companyId', bbdd.deleteCompany);

    //------------------------------------------------------------

    //create worker
    app.post('/api/worker/:workerId', bbdd.createWorker);

    //show worker
    app.get('api/worker/:workerId', bbdd.findOneWorker);

    //update worker
    app.put('api/worker/:workerId', bbdd.updateWorker);

    //delete worker
    app.delete('api/worker/:workerId', bbdd.deleteWorker);








}