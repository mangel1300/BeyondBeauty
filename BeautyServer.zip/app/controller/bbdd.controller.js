const Customer = require('../models/user.model.js');

const Worker = require('../models/worker.model.js');

const Company = require('../models/company.model.js');

const GServices = require('../models/gservices.model.js');

const Faq = require('../models/faq.model.js');

const Account = require('../models/account.model.js');

//post a customer
exports.createUser = (req, res) => {
    const customer = new Customer(req.body);

    customer.save()
    .then(data =>{
        res.json(data);
    }).catch(err => {
        res.status(500).json({
            msg: err.message
        });
    });
};

// find a customer
exports.findOneUser = (req, res) => {
    Customer.findById(req.params.customerId)
    .then(customer => {
        if(!customer) {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });            
        }
        res.json(customer);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });                
        }
        return res.status(500).json({
            msg: "Error retrieving Customer with id " + req.params.customerId
        });
    });
};

// update a customer
exports.updateUser = (req, res) => {
    // Find customer and update it
    Customer.findByIdAndUpdate(req.body._id, req.body, {new: true})
    .then(customer => {
        if(!customer) {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });
        }
        res.json(customer);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });                
        }
        return res.status(500).json({
            msg: "Error updating customer with id " + req.params.customerId
        });
    });
};

// delete a customer
exports.deleteUser = (req, res) => {
    Customer.findByIdAndRemove(req.params.customerId)
    .then(customer => {
        if(!customer) {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });
        }
        res.json({msg: "Customer deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).json({
                msg: "Customer not found with id " + req.params.customerId
            });                
        }
        return res.status(500).json({
            msg: "Could not delete customer with id " + req.params.customerId
        });
    });
};

//-------------------------------------------------------------

//post a company
exports.createCompany = (req, res) => {
    const company = new Company(req.body);

    company.save()
    .then(data =>{
        res.json(data);
    }).catch(err => {
        res.status(500).json({
            msg: err.message
        });
    });
};

// find all companies
exports.findAllCompanies = (req, res) => {
    Company.find()
    .then(company => {
        res.json(company);
    }).catch(err => {
        res.status(500).send({
            msg: err.message
        });
    });
};

// find a company
exports.findOneCompany = (req, res) => {
    Company.findById(req.params.company)
    .then(company => {
        if(!company) {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });            
        }
        res.json(company);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });                
        }
        return res.status(500).json({
            msg: "Error retrieving Company with id " + req.params.companyId
        });
    });
};

// update a company
exports.updateCompany = (req, res) => {
    // Find company and update it
    Company.findByIdAndUpdate(req.body._id, req.body, {new: true})
    .then(company => {
        if(!company) {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });
        }
        res.json(company);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });                
        }
        return res.status(500).json({
            msg: "Error updating company with id " + req.params.companyId
        });
    });
};

// delete a company
exports.deleteCompany = (req, res) => {
    Company.findByIdAndRemove(req.params.companyId)
    .then(company => {
        if(!company) {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });
        }
        res.json({msg: "Company deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).json({
                msg: "Company not found with id " + req.params.companyId
            });                
        }
        return res.status(500).json({
            msg: "Could not delete company with id " + req.params.companyId
        });
    });

//---------------------------------------------------------------

};//post a worker
exports.createWorker = (req, res) => {
    const worker = new Worker(req.body);

    worker.save()
    .then(data =>{
        res.json(data);
    }).catch(err => {
        res.status(500).json({
            msg: err.message
        });
    });
};

// find a customer
exports.findOneWorker = (req, res) => {
    Worker.findById(req.params.workerId)
    .then(worker => {
        if(!worker) {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });            
        }
        res.json(worker);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });                
        }
        return res.status(500).json({
            msg: "Error retrieving Worker with id " + req.params.workerId
        });
    });
};

// update a worker
exports.updateWorker = (req, res) => {
    // Find worker and update it
    Worker.findByIdAndUpdate(req.body._id, req.body, {new: true})
    .then(worker => {
        if(!worker) {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });
        }
        res.json(worker);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });                
        }
        return res.status(500).json({
            msg: "Error updating worker with id " + req.params.workerId
        });
    });
};

// delete a worker
exports.deleteWorker = (req, res) => {
    Worker.findByIdAndRemove(req.params.workerId)
    .then(worker => {
        if(!worker) {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });
        }
        res.json({msg: "Worker deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).json({
                msg: "Worker not found with id " + req.params.workerId
            });                
        }
        return res.status(500).json({
            msg: "Could not delete worker with id " + req.params.workerId
        });
    });
};

//---------------------------------------------------------------

// find all general services
exports.findAllGServices = (req, res) => {
    GServices.find()
    .then(Gservices => {
        res.json(Gservices);
    }).catch(err => {
        res.status(500).send({
            msg: err.message
        });
    });
};

//---------------------------------------------------------------

//find all questions
exports.findAllQuestions = (req, res) => {
    Faq.find()
    .then(faq => {
        res.json(faq);
    }).catch(err => {
        res.status(500).send({
            msg: err.message
        });
    });
};

//---------------------------------------------------------------

//create account
exports.createAccount = (req, res) => {
    const account = new Account(req.body);

    account.save()
    .then(data => {
        res.json(data);
    }).catch(err=> {
        res.status(500).json({
            msg: err.message
        });
    });
};

//find account
exports.findAccount = (req, user) => {
    const account = new Account(req.body);
    
    Account.findOne({nickname: account.nickname, password: account.password}, 
        function(err, res) {
            if (err)
                res.send(err);
            else {
                user.json(res);
            }
        });
}