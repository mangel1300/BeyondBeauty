const mongoose = require('mongoose');

const companySchema = mongoose.Schema({
    name: {type: String, required: true},
    email: {type: String, required: true},
    password: {type: String, required: true},
    nif: {type: String, required: true},
    iban: {type: String, required: true},
    schedule: [{
        monday: [{start: String, end: String}],
        tuesday: [{start: String, end: String}],
        wednesday: [{start: String, end: String}],
        thursday: [{start: String, end: String}],
        friday: [{start: String, end: String}],
        saturday: [{start: String, end: String}]
    }],
    direction: String,
    map: String,
    offers:[{
        offer:[{
            title: String,
            price: Number,
            time: Number,
            percentage: Number,
            start_day: Date,
            end_day: Date
        }]
    }],
    services: [{
        service: [{
            title: String,
            price: Number,
            time: Number
        }]
    }],
    comments: [{
       comment: [{
        nick:String,
        rate: Number,
        text: String
       }]
    }],
    reservations: [{
        reservation: [{
            day: Date,
            hour: Number,
            firstName: String,
            secondName: String,
            phoneNumber: String,
            email: String,
            worker: String,
            payMethod: String
        }]
    }]
})

module.exports = mongoose.model('company', companySchema);