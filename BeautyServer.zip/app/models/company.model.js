const mongoose = require('mongoose');

const companySchema = mongoose.Schema({
    name: {type: String, required: true},
    email: {type: String, required: true},
    password: {type: String, required: true},
    nif: {type: String, required: true},
    iban: {type: String, required: true},
    schedule: [
        String,//lunes
        String,//martes
        String,//miercoles
        String,//jueves
        String,//viernes
        String //sabado
    ],
    direction: String,
    map: String,
    offers:[
        String,//titulo
        Number,//precio
        Number, //tiempo
        Number,//porcentaje
        Date,//fecha de inicio
        Date//fecha de limite
    ],
    services: [
        String,
        Number,
        Number
    ],
    comments: [{
        String,//apodo
        Number,//puntuacion
        String//comentario
    }],
    reservations: [
        Date,//dia
        Number,//hora
        String,//nombre
        String,//apellido
        String,//numero de telefono
        String,//email
        String,//trabajador
        String//metodo de pago
    ]
})

module.exports = mongoose.model('company', companySchema);