const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    nickname: {type:String, required: true},
    firstName: {type: String, required: true},
    secondName: {type: String, required: true},
    password: {type: String, required: true},
    email: {type: String, required: true},
    phoneNumber: Number,
    points: Number
})

module.exports = mongoose.model('User', userSchema);