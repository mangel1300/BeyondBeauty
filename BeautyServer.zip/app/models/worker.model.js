const mongoose = require('mongoose');

const workerSchema = mongoose.Schema({
    firstName: {type: String, required: true},
    secondName: {type: String, required: true},
    dni:String,
    email: String,
    password: String,
    dateBorn: Date,
    ocupation: String,
    company: String,
    quadrant:[
        String,//lunes
        String,//martes
        String,//miercoles
        String,//jueves
        String,//viernes
        String //sabado
    ]
})

module.exports = mongoose.model('worker', workerSchema);