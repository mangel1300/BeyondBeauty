const mongoose = require('mongoose');

const workerSchema = mongoose.Schema({
    firstName: {type: String, required: true},
    secondName: {type: String, required: true},
    dni:String,
    email: String,
    ocupation: {type: String, required: true},
    company: {type: String, required: true},
    quadrant:[{
        monday: [{start: String, end: String}],
        tuesday: [{start: String, end: String}],
        wednesday: [{start: String, end: String}],
        thursday: [{start: String, end: String}],
        friday: [{start: String, end: String}],
        saturday: [{start: String, end: String}]
    }]
})

module.exports = mongoose.model('worker', workerSchema);